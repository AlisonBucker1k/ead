<?php

namespace Blockchain\Explorer;

class FilterType
{
    const All = 4;
    const ConfirmedOnly = 5;
    const RemoveUnspendable = 6;
}